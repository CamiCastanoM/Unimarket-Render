/* ================================================
   main.js — UniMarket
   Universidad del Magdalena
   ================================================ */

// ==================== VIEW SWITCHING ====================
function showView(name) {
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  const target = document.getElementById('view-' + name);
  if (target) {
    target.classList.add('active');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }
}


// ==================== DATOS EN VISTA DETALLE ====================
function verProducto(event, cardElement) {

  // Evitar abrir producto al hacer click en botones
  if (event.target.closest('button')) return;

  // Evitar abrir producto al hacer click en favoritos
  if (event.target.closest('.fav-btn')) return;

  const title = cardElement.querySelector('.card-title').textContent;
  const imgSrc = cardElement.querySelector('.card-img').src;
  const productId = cardElement.dataset.id;

  const favBtn = cardElement.querySelector('.fav-btn');
  const isFavorite = favBtn ? favBtn.classList.contains('active') : false;

  const priceNode = cardElement.querySelector('.card-price').childNodes[0];
  const price = priceNode ? priceNode.nodeValue.trim() : "$0";

  let seller = '';

  const sellerElement = cardElement.querySelector('.card-seller');

  if (sellerElement) {
    seller = sellerElement.textContent.replace(/🌟|📚|💻|📓/g, '').trim();
  }

  const ubicacion = cardElement.dataset.ubicacion || '';
  const descripcion = cardElement.dataset.descripcion || '';

  document.getElementById('detail-title').textContent = title;
  document.getElementById('breadcrumb-product-name').textContent = title;
  document.getElementById('detail-price').textContent = price;
  document.getElementById('main-gallery-img').src = imgSrc;
  document.getElementById('detail-seller').textContent = seller;
  document.getElementById('detail-ubicacion').textContent = ubicacion;
  document.getElementById('detail-descripcion').textContent = descripcion;

  // Ver tienda
  const detailVerTienda = document.getElementById('detail-ver-tienda');

  if (detailVerTienda) {
    detailVerTienda.dataset.id = cardElement.dataset.idVendedor;
  }

  // Contactar vendedor
  const detailBtnContactar = document.getElementById('detail-btn-contactar');

  if (detailBtnContactar) {
    detailBtnContactar.dataset.id = cardElement.dataset.idVendedor;
  }

  showView('product');
}

// ==================== CATEGORY PILLS (FILTROS) ====================
function initCatPills() {
  document.querySelectorAll('.cat-pills').forEach(container => {
    container.querySelectorAll('.cat-pill').forEach(pill => {
      pill.addEventListener('click', function () {
        container.querySelectorAll('.cat-pill').forEach(p => p.classList.remove('active'));
        this.classList.add('active');

        const targetCat = this.getAttribute('data-target');
        const view = this.closest('.view');

        if (view) {
          let count = 0;
          const cards = view.querySelectorAll('.product-card');

          cards.forEach(card => {
            const cardCat = card.getAttribute('data-cat');
            if (targetCat === 'all' || cardCat === targetCat) {
              card.style.display = 'block';
              count++;
              card.style.animation = 'none';
              setTimeout(() => card.style.animation = 'fadeIn 0.35s ease both', 10);
            } else {
              card.style.display = 'none';
            }
          });

          const countText = view.querySelector('#resultados-count');
          if (countText) countText.textContent = `Mostrando ${count} resultados`;
        }
      });
    });
  });
}

// ==================== MORE TABS (EXPANDIR OPCIONES) ====================
function initMoreTabs() {
  document.querySelectorAll('.more-tabs').forEach(tabBar => {
    tabBar.querySelectorAll('.more-tab').forEach(tab => {
      tab.addEventListener('click', function () {
        tabBar.querySelectorAll('.more-tab').forEach(t => t.classList.remove('active'));
        this.classList.add('active');

        const targetCat = this.getAttribute('data-target');
        const grid = document.getElementById('mini-productos-grid');

        if (grid) {
          grid.querySelectorAll('.mini-card').forEach(card => {
            const cardCat = card.getAttribute('data-cat');
            if (targetCat === 'all' || cardCat === targetCat) {
              card.style.display = 'block';
            } else {
              card.style.display = 'none';
            }
          });
        }
      });
    });
  });
}

function switchProfileTab(btn, sectionId) {
  // 1. Quitar 'active' de todas los botones de pestaña del perfil
  const tabs = btn.parentElement.querySelectorAll('.more-tab');
  tabs.forEach(t => t.classList.remove('active'));

  // 2. Ocultar todas las secciones de contenido del perfil
  const sections = document.querySelectorAll('.profile-content-section');
  sections.forEach(s => s.style.display = 'none');

  // 3. Activar el botón clicado y mostrar su sección
  btn.classList.add('active');
  const target = document.getElementById(sectionId);
  if (target) {
    target.style.display = 'block';
    // Si activamos la pestaña de favoritos, refrescar el contenido vía AJAX
    if (sectionId === 'profile-fav') {
      refreshFavoritosView();
    }
  }
}

function refreshFavoritosView() {
  const grid = document.getElementById('profile-fav-grid');
  if (!grid) return;

  fetch('../../controlador/FavoritoController.php?accion=listar_html')
    .then(response => response.text())
    .then(html => {
      grid.innerHTML = html;
    });
}

function toggleFavorito(id_producto, btn) {
  const formData = new FormData();
  formData.append('id_producto', id_producto);

  fetch('../../controlador/FavoritoController.php?accion=toggle', {
    method: 'POST',
    body: formData
  })
    .then(response => response.json())
    .then(data => {
      if (data.status === 'success') {
        // Sincronizar TODOS los corazones de este producto en la página actual
        const allHearts = document.querySelectorAll(`[onclick*="toggleFavorito(${id_producto}"]`);
        const isNowActive = !btn.classList.contains('active');

        allHearts.forEach(heart => {
          if (isNowActive) {
            heart.classList.add('active');
            heart.textContent = '❤️';
          } else {
            heart.classList.remove('active');
            heart.textContent = '🤍';
          }
        });

        // Si estamos en la vista de perfil, refrescamos la lista
        if (document.getElementById('profile-fav-grid')) {
          refreshFavoritosView();
        }
      } else {
        alert(data.message || 'Error al actualizar favoritos');
        if (data.message === 'Debes iniciar sesión') {
          showView('auth');
        }
      }
    })
    .catch(error => {
      console.error('Error:', error);
    });
}





// ==================== GALLERY THUMBS ====================
function changeImg(thumb, src) {
  const mainImg = document.getElementById('main-gallery-img');
  if (mainImg) mainImg.src = src;
  document.querySelectorAll('.thumb').forEach(t => t.classList.remove('active'));
  thumb.classList.add('active');
}

function updateTimer() {
  // 1. Reloj general del sidebar (Solo estético para la maqueta)
  const sidebarHours = document.getElementById('hours');
  const sidebarMinutes = document.getElementById('minutes');
  const sidebarSeconds = document.getElementById('seconds');

  if (sidebarHours) {
    // Usamos la hora sincronizada del servidor
    const ahora = new Date(Date.now() + (window.serverOffset || 0));
    let endOfDay = new Date(ahora);
    endOfDay.setHours(23, 59, 59);
    let diff = endOfDay - ahora;
    let h = Math.floor(diff / 3600000);
    let m = Math.floor((diff % 3600000) / 60000);
    let s = Math.floor((diff % 60000) / 1000);
    sidebarHours.textContent = String(h).padStart(2, '0');
    sidebarMinutes.textContent = String(m).padStart(2, '0');
    sidebarSeconds.textContent = String(s).padStart(2, '0');
  }

  // 2. Contadores individuales de cada Venta Flash real
  document.querySelectorAll('.flash-card-horizontal').forEach(card => {
    let finStr = card.getAttribute('data-fin');
    if (!finStr) return;

    // Reemplazamos el espacio por 'T' para que sea compatible con todos los navegadores
    finStr = finStr.replace(" ", "T");
    const fin = new Date(finStr);
    const ahora = new Date(Date.now() + (window.serverOffset || 0));
    const diff = fin - ahora;

    const timerDisplay = card.querySelector('.timer-display');
    if (!timerDisplay) return;

    if (diff <= 0) {
      card.style.opacity = '0.5';
      timerDisplay.textContent = "Expirado";
      return;
    }

    const h = Math.floor(diff / 3600000);
    const m = Math.floor((diff % 3600000) / 60000);
    const s = Math.floor((diff % 60000) / 1000);

    let text = "";
    if (h > 0) text += h + "h ";
    text += m + "m " + s + "s";

    timerDisplay.textContent = text;
  });
}


function initCountdown() {
  updateTimer();
  setInterval(updateTimer, 1000);
}


// ==================== STORE FILTER ITEMS ====================
function initFilterItems() {
  document.querySelectorAll('.filter-item').forEach(item => {
    item.addEventListener('click', function () {
      const sidebar = this.closest('.store-sidebar');
      if (sidebar) {
        sidebar.querySelectorAll('.filter-item').forEach(fi => {
          fi.style.background = '';
          fi.style.color = '';
        });
      }
      this.style.background = 'var(--gray-100)';
      this.style.color = 'var(--primary)';
    });
  });
}

// ==================== MOBILE NAV ====================
function setMobileActive(el) {
  document.querySelectorAll('.mobile-nav li').forEach(li => li.classList.remove('active'));
  el.classList.add('active');
}

function toggleMobileMenu() {
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

// ==================== FAV BUTTON ====================
function initFavButtons() {
  document.querySelectorAll('.fav-btn').forEach(btn => {
    btn.addEventListener('click', function (e) {
      e.stopPropagation();
      this.textContent = this.textContent.trim() === '🤍' ? '❤️' : '🤍';
    });
  });
}

// ==================== PUBLISH FORM PREVIEW (CON SUBIDA REAL) ====================
// ---SUBIR ARCHIVO REAL (MANEJADOR) ---
function handleImagePreview(input) {
  const file = input.files[0];
  const fileNameLabel = document.getElementById('file-name');
  const previewCont = document.getElementById('preview-img-cont');
  const sidePreviewCont = document.getElementById('prev-img-display');

  if (file) {
    const objectUrl = URL.createObjectURL(file);
    const imgHtml = `<img src="${objectUrl}" style="width:100%; height:100%; object-fit:cover; border-radius:var(--radius-sm);">`;
    
    // Actualizar nombre
    if (fileNameLabel) fileNameLabel.innerText = file.name;
    
    // Actualizar previsualización en el dropzone
    if (previewCont) previewCont.innerHTML = imgHtml;
    
    // Actualizar previsualización en la tarjeta lateral (Vista Previa)
    if (sidePreviewCont) {
      sidePreviewCont.innerHTML = imgHtml;
      sidePreviewCont.style.background = 'transparent';
    }
  }
}

function handleFlashImagePreview(input) {
  const file = input.files[0];
  const previewCont = document.getElementById('flash-preview-cont');

  if (file) {
    const objectUrl = URL.createObjectURL(file);
    if (previewCont) {
      previewCont.innerHTML = `<img src="${objectUrl}" style="width:100%; height:80px; object-fit:cover; border-radius:var(--radius-sm); margin-top:5px;">`;
    }
  }
}

function initPublishPreview() {
  const titleInput = document.getElementById('pub-title');
  const priceInput = document.getElementById('pub-price');
  const previewTitle = document.getElementById('prev-title');
  const previewPrice = document.getElementById('prev-price');

  // Actualizar Título
  if (titleInput && previewTitle) {
    titleInput.addEventListener('input', function () {
      previewTitle.textContent = this.value || 'Título del producto';
    });
  }

  // Actualizar Precio
  if (priceInput && previewPrice) {
    priceInput.addEventListener('input', function () {
      const val = parseInt(this.value, 10);
      previewPrice.textContent = val ? '$' + val.toLocaleString('es-CO') : '$0';
    });
  }
}

// ==================== PUBLISH STEPS ====================
function initPublishSteps() {
  const steps = document.querySelectorAll('.step-item');
  steps.forEach((step, i) => {
    step.addEventListener('click', function () {
      steps.forEach(s => s.classList.remove('active'));
      this.classList.add('active');
    });
  });
}

// ==================== BÚSQUEDA Y ORDENAMIENTO ====================
function initSearchAndSort() {
  const desktopSearch = document.querySelector('.navbar-search input'); // El de arriba
  const mobileSearch = document.getElementById('main-search-input');   // El nuevo de la vista search
  const sortSelect = document.querySelector('.sort-select');

  // Función genérica de filtrado
  const performSearch = (term, gridId) => {
    const grid = document.getElementById(gridId) || document.querySelector('.products-grid');
    const cards = grid.querySelectorAll('.product-card');
    let count = 0;
    const cleanTerm = term.toLowerCase().trim();

    cards.forEach(card => {
      const title = card.querySelector('.card-title').textContent.toLowerCase();
      if (title.includes(cleanTerm)) {
        card.style.display = 'block';
        count++;
      } else {
        card.style.display = 'none';
      }
    });

    // Actualizar contadores
    const countDisplay = document.getElementById('search-count') || document.getElementById('resultados-count');
    if (countDisplay) {
      countDisplay.textContent = cleanTerm === "" ? "Escribe algo para buscar..." : `Mostrando ${count} resultados`;
    }
  };

  // Listener para el buscador de escritorio
  if (desktopSearch) {
    desktopSearch.addEventListener('input', (e) => performSearch(e.target.value, 'view-home'));
  }

  // Listener para el buscador de la nueva vista (Móvil)
  if (mobileSearch) {
    mobileSearch.addEventListener('input', (e) => performSearch(e.target.value, 'search-grid'));
  }
}

// ==================== INIT ====================
document.addEventListener('DOMContentLoaded', () => {
  initCatPills();
  initCountdown();
  initMoreTabs();
  initFilterItems();
  initFavButtons();
  initPublishPreview();
  initPublishSteps();

  // ¡Aquí está la llamada correcta para que funcione el buscador!
  initSearchAndSort();
});

// ==================== FUNCIONES VENTA FLASH ====================

// Abre el modal de publicación rápida para estudiantes
function openFlashModal() {
  const modal = document.getElementById('flash-modal');
  if (modal) {
    modal.style.display = 'flex';
  }
}

// Cierra el modal de venta flash
function closeFlashModal() {
  const modal = document.getElementById('flash-modal');
  if (modal) {
    modal.style.display = 'none';
  }
}

// Cambia el texto visual cuando el estudiante selecciona una foto (Cámara o Galería)
function handleFlashPhoto(input) {
  const text = document.getElementById('flash-upload-text');
  if (input.files && input.files[0] && text) {
    text.innerHTML = "✅ ¡Foto cargada con éxito!";
    text.style.color = "var(--green)";
  }
}

// Simula la publicación de la oferta efímera en el campus
function publishFlashNow() {
  const priceInput = document.getElementById('flash-price-input');
  const locationInput = document.getElementById('flash-location-input');

  if (!priceInput || !priceInput.value) {
    alert("Por favor, ponle un precio a tu oferta.");
    return;
  }

  const price = priceInput.value;
  const location = locationInput ? locationInput.value : "el campus";

  // Simulación de éxito para la maqueta
  alert(`⚡ ¡Publicado! Tu oferta de $${price} en ${location} estará activa por 2 horas.`);

  //Limpieza y redirección
  closeFlashModal();
  if (typeof showView === 'function') {
    showView('flash');
  }
}

// ==================== NOTIFICACIONES Y MENSAJERÍA ====================

function fetchNotificaciones() {
  const badgeBtn = document.getElementById('btn-noti') || document.querySelector('.nav-icon-btn');
  fetch('../../controlador/NotificacionController.php?accion=listar')
    .then(r => r.json())
    .then(data => {
      if(data.status === 'success' && data.data) {
        const container = document.getElementById('notificaciones-lista');
        if(container) {
          if(data.data.length > 0) {
            container.innerHTML = '';
            data.data.forEach(n => {
              container.innerHTML += `
              <div onclick="handleNotificacionClick(${n.id_notificacion}, '${n.url}')" style="padding: 10px; border-bottom: 1px solid #eee; cursor: pointer; transition: background 0.2s;" onmouseover="this.style.background='#f0f4f8'" onmouseout="this.style.background='white'">
                <p style="margin:0; font-size: 0.9rem;">${n.mensaje}</p>
                <small style="color:var(--gray-500)">${new Date(n.fecha).toLocaleString()}</small>
              </div>`;
            });
            if (badgeBtn) badgeBtn.innerHTML = '🔔 <span style="background:red; color:white; border-radius:50%; font-size:0.6rem; padding:2px 5px; position:absolute; top:-5px; right:-5px;">new</span>';
          } else {
             container.innerHTML = '<p style="color: #9ca3af; text-align: center; padding: 15px 10px; font-size: 0.85rem;">No hay notificaciones nuevas</p>';
             if (badgeBtn) badgeBtn.innerHTML = '🔔';
          }
        }
      }
    });
}

function handleNotificacionClick(id, url) {
    // 1. Marcar como leída
    fetch('../../controlador/NotificacionController.php?accion=marcar_leida', {
        method: 'POST',
        body: JSON.stringify({id_notificacion: id})
    }).then(() => {
        fetchNotificaciones();
        
        // 2. Redirigir si tiene URL de chat
        if(url && url.startsWith('chat/')) {
            const sellerId = url.split('/')[1];
            iniciarChatVendedor(sellerId);
        }
    });
}

function marcarNotificacionLeida(id) {
  fetch('../../controlador/NotificacionController.php?accion=marcar_leida', {
    method: 'POST',
    body: JSON.stringify({id_notificacion: id})
  }).then(r => {
     fetchNotificaciones();
  });
}

document.addEventListener('DOMContentLoaded', () => {
    fetchNotificaciones();
    // Poll notifications every 30s
    setInterval(fetchNotificaciones, 30000);
});

let chatInterval = null;

function fetchConversacion(id_destinatario) {
    if (!id_destinatario) return;
    
    fetch(`../../controlador/MensajeController.php?accion=listar&id_destinatario=${id_destinatario}`)
      .then(async r => {
          const text = await r.text();
          try {
              return JSON.parse(text);
          } catch(e) {
              console.error("Mensaje fetch json error:", text);
              return {status: 'error', message: 'Error de respuesta del servidor'};
          }
      })
      .then(data => {
         const container = document.getElementById('mensajes-lista');
         if (data.status === 'success') {
             container.innerHTML = '';
             if(data.data.length === 0) {
                 container.innerHTML = '<p style="text-align: center; color: #9ca3af; margin-top: 50px;">No hay mensajes previos. ¡Comienza saludando!</p>';
             } else {
                 data.data.forEach(m => {
                     const isMiMensaje = m.id_destinatario == id_destinatario;
                     container.innerHTML += `
                     <div style="margin-bottom: 10px; text-align: ${isMiMensaje ? 'right' : 'left'};">
                         <div style="display:inline-block; max-width: 70%; padding: 10px; border-radius: 8px; background: ${isMiMensaje ? 'var(--primary)' : '#e5e7eb'}; color: ${isMiMensaje ? 'white' : 'black'}; text-align: left;">
                             ${m.contenido}
                         </div>
                         <div style="font-size: 0.7rem; color: var(--gray-400); margin-top: 2px;">${new Date(m.fecha_envio).toLocaleString()}</div>
                     </div>`;
                 });
                 // auto scroll to bottom
                 container.scrollTop = container.scrollHeight;
             }
         } else {
             container.innerHTML = `<p style="text-align: center; color: var(--red); margin-top: 50px;">Error: ${data.message}</p>`;
         }
      })
      .catch(e => console.error("Network error on fetchConversacion:", e));
      
    if(chatInterval) clearInterval(chatInterval);
    chatInterval = setInterval(() => {
        fetchConversacion(document.getElementById('chat-user-select').value);
    }, 5000);
}

function enviarMensaje() {
    const id_destinatario = document.getElementById('chat-user-select').value;
    const input = document.getElementById('mensaje-input');
    const contenido = input.value;
    
    if(!id_destinatario || !contenido.trim()) return;
    
    const formData = new FormData();
    formData.append('id_destinatario', id_destinatario);
    formData.append('contenido', contenido);
    
    fetch('../../controlador/MensajeController.php?accion=enviar', {
        method: 'POST',
        body: formData
    })
    .then(r => r.json())
    .then(data => {
        if(data.status === 'success') {
            input.value = '';
            fetchConversacion(id_destinatario);
        } else {
            alert(data.message);
        }
    });
}

function iniciarChatVendedor(id_vendedor) {
    if(!id_vendedor) return;
    
    // Abrir la vista de mensajes
    showView('messages');
    
    // Auto-seleccionar al vendedor en el combobox de conversaciones
    const select = document.getElementById('chat-user-select');
    if (select) {
        let optionExists = false;
        for (let i = 0; i < select.options.length; i++) {
            if (select.options[i].value == id_vendedor) {
                optionExists = true;
                break;
            }
        }
        
        if (optionExists) {
            select.value = id_vendedor;
            fetchConversacion(id_vendedor);
        } else {
            // Si el select no tiene a esta persona (ej. eres tú mismo, o no has iniciado sesión)
            alert("No puedes iniciar un chat con este vendedor (podrías ser tú mismo o necesitas iniciar sesión).");
            showView('home');
        }
    } else {
        alert("Debes iniciar sesión para usar los mensajes.");
        showView('auth');
    }
}

function verTienda(id_vendedor) {
    if(!id_vendedor) return;

    // 1. Mostrar vista tienda (con cargando si quieres, pero lo haremos rápido)
    showView('store');

    // 2. Obtener info del vendedor
    fetch(`../../controlador/UsuarioController.php?accion=obtener_info&id=${id_vendedor}`)
        .then(r => r.json())
        .then(res => {
            if(res.status === 'success' && res.data) {
                const nombre = res.data.nombre;
                document.querySelector('.store-name').innerHTML = `${nombre} <span class="stars">★★★★★</span>`;
                const titleEl = document.getElementById('store-section-title');
                if(titleEl) titleEl.textContent = `Productos de ${nombre}`;
                
                const bread = document.getElementById('breadcrumb-store-name');
                if(bread) bread.textContent = nombre;
                
                const banner = document.getElementById('store-banner-img');
                if(banner) banner.alt = `Banner ${nombre}`;
                
                const logo = document.getElementById('store-logo-text');
                if(logo) {
                    let initials = nombre.substring(0, 2);
                    if(nombre.includes(' ')) {
                        const parts = nombre.split(' ');
                        initials = parts[0].charAt(0) + parts[1].charAt(0);
                    }
                    logo.textContent = initials.toUpperCase();
                }
            }
        });

    // 3. Obtener productos del vendedor
    fetch(`../../controlador/ProductoController.php?accion=listar_por_usuario&id_usuario=${id_vendedor}`)
        .then(r => r.json())
        .then(res => {
            const grid = document.getElementById('store-grid');
            if(res.status === 'success' && res.data && grid) {
                grid.innerHTML = '';
                if(res.data.length === 0) {
                    grid.innerHTML = '<p style="color:var(--gray-500); padding: 20px;">Esta tienda no tiene productos publicados.</p>';
                } else {
                    const catMap = { 1: 'libros', 2: 'tecnologia', 3: 'comida', 4: 'ropa', 5: 'otros' };
                    // Obtener nombre limpio sin estrellas
                    const cleanName = document.querySelector('.store-name').textContent.split('★')[0].trim();
                    
                    res.data.forEach(p => {
                        const slug = catMap[p.id_categoria] || 'otros';
                        const imgPath = p.imagen ? `uploads/productos/${p.imagen}` : 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=400&h=200&fit=crop';
                        grid.innerHTML += `
                        <div class="product-card" onclick="verProducto(event, this)" data-id="${p.id_producto}" data-id-vendedor="${id_vendedor}" data-cat="${slug}">
                            <img class="card-img" src="${imgPath}" alt="${p.nombre}">
                            <div class="card-body">
                                <div class="card-title">${p.nombre}</div>
                                <div class="card-price">$${new Intl.NumberFormat('es-CO').format(p.precio)}</div>
                                <div class="card-seller">🌟 ${cleanName}</div>
                                <button class="btn-aprovechar">Aprovechar</button>
                            </div>
                        </div>`;
                    });
                }
            }
        }
        
    );


}

// ==================== CRUD FLASH ====================

function editarFlash(idFlash){

    window.location.href =
        "editar_venta_flash.php?id=" + idFlash;

}

function eliminarFlash(idFlash){

    if(confirm("¿Eliminar esta venta flash?")){

        window.location.href =
            "../../controlador/FlashController.php?accion=eliminar&id=" + idFlash;

    }

}


// ==================== CRUD PRODUCTOS ====================

function editarProducto(idProducto){

    window.location.href =
        "editar_producto.php?id=" + idProducto;

}

function pausarProducto(idProducto){

    alert("Producto pausado temporalmente");

}


// ==================== CARGA DE VISTAS ====================

window.addEventListener('DOMContentLoaded', () => {

    const params = new URLSearchParams(window.location.search);

    const view = params.get('view');

    // verificar login real
    const isLogged =
        document.body.dataset.logged === "1";

    if (view && document.getElementById('view-' + view)) {

        // bloquear perfil sin sesión
        if(view === 'profile' && !isLogged){

            showView('home');
            return;

        }

        setTimeout(() => {

            showView(view);

        }, 100);

    }

});