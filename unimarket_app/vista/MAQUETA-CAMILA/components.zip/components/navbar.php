<nav class="navbar">
  <div class="navbar-logo" onclick="showView('home')">
    <div class="logo-icon">🛍️</div>
    UniMarket
  </div>

  <div class="navbar-search">
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
      <circle cx="11" cy="11" r="8"/>
      <path d="m21 21-4.35-4.35"/>
    </svg>
    <input type="text" placeholder="Buscar productos, comida, libros...">
  </div>

  <div class="navbar-actions">
    <?php if ($idRol == 1): // Solo el vendedor ve el botón general de publicar ?>
        <button class="btn-nav-link" onclick="showView('publish')">Publicar</button>
    <?php endif; ?>
    <?php if ($idRol != 1): ?>
        <button class="btn-nav-link" onclick="showView('purchases')">Mis compras</button>
    <?php endif; ?>
    
    <?php if ($nombreUsuario): ?>
        <span class="btn-nav-link" style="font-weight: 800; color: #004a87;">
            👋 Hola, <?php echo $nombreUsuario; ?>
        </span>
        <a href="../../controlador/UsuarioController.php?accion=logout" class="btn-primary" style="text-decoration: none; background: #e5e7eb; color: #374151; font-size: 0.8rem; padding: 5px 10px;">
            Salir
        </a>
    <?php else: ?>
        <button class="btn-primary" onclick="showView('auth')">Iniciar sesión</button>
    <?php endif; ?>

    <div style="position: relative; display: inline-block;">
      <button class="nav-icon-btn" onclick="document.getElementById('notificaciones-dropdown').style.display = document.getElementById('notificaciones-dropdown').style.display === 'none' ? 'block' : 'none';">🔔</button>
      <div id="notificaciones-dropdown" style="display: none; position: absolute; top: 100%; right: 0; background: white; border: 1px solid #e5e7eb; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1); border-radius: 8px; width: 250px; padding: 10px; z-index: 1000; text-align: left;">
        <h4 style="margin: 0 0 10px 0; font-size: 0.9rem; color: #4b5563; border-bottom: 1px solid #eee; padding-bottom: 5px;">Notificaciones</h4>
        <div id="notificaciones-lista" style="font-size: 0.85rem; color: #1f2937;">
          <p style="color: #9ca3af; text-align: center; margin: 10px 0;">No hay notificaciones</p>
        </div>
      </div>
    </div>
    
    <button class="nav-icon-btn" onclick="showView('messages')">✉️</button>
    <button class="nav-icon-btn" onclick="showView('profile')">👤</button>
    <button class="hamburger nav-icon-btn" onclick="toggleMobileMenu()">☰</button>
  </div>
</nav>
